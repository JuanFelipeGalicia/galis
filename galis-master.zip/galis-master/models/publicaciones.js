let publicacion = function(sequelize,Sequelize){
    let modelo = sequelize.define(
        "semillero",
        {
            
            "idPublicacion":{ 
                primaryKey:true,
                autoIncrement:true,
                type: Sequelize.INTEGER

                },
                "fechaPublicacion":{
                    notEmpty: true,
                    type: Sequelize.STRING
                },

                "descripcionSemillero":{
                    notEmpty: true,
                    type: Sequelize.STRING
                },

                "textoPublicacion":{
                     notEmpty: true,
                    type: Sequelize.STRING
                }
        },
        
         {
            timestamps: false,
            freezeTableName:true
         }
    );
    return modelo;

};

module.exports = publicacion;